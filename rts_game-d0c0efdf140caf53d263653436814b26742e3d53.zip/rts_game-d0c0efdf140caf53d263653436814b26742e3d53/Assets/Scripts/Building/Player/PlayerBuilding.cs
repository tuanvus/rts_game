﻿using UnityEngine;

namespace RTS.Buildings
{
    public class PlayerBuilding : MonoBehaviour
    {
        public BuildingStatType.Base baseStats;
    }
}