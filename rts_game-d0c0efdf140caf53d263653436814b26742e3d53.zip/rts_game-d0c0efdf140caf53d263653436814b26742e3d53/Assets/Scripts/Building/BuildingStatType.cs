﻿using UnityEngine;
namespace RTS.Buildings
{
    public class BuildingStatType : MonoBehaviour
    {
      [System.Serializable]
      public class Base
        {
            public float health, armor, attack;
        }    

    }
}