﻿using UnityEngine;
namespace RTS.Buildings
{

public class BuildingActions : MonoBehaviour
{
    [System.Serializable]
    public class BuildingUnits
    {
        public RTS.Units.BasicUnit[] basicUnits;
    }
}
}
