﻿using UnityEngine;

namespace MiddleMast
{
    public class TestObject : ScriptableObject
    {
        [SerializeField] string _didItWork = "Maybe";
    }
}